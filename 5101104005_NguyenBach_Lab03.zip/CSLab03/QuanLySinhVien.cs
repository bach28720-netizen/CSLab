﻿using System;
using System.Collections.Generic;
using System.Linq;

public class QuanLySinhVien
{
    private List<SinhVien> danhSach = new List<SinhVien>();

    public void ThemSinhVien(SinhVien sv) 
    {
        if (danhSach.Any(s => s.MaSinhVien == sv.MaSinhVien))
        {
            Console.WriteLine("Mã sinh viên đã tồn tại!");
            return;
        }
        danhSach.Add(sv);
        Console.WriteLine("Thêm thành công!");
    }

    public void XuatDanhSach() 
    {
        if (danhSach.Count == 0) Console.WriteLine("Danh sách trống.");
        foreach (var sv in danhSach) sv.LayThongTin();
    }

    public void TimTheoMa(string ma) 
    {
        var sv = danhSach.FirstOrDefault(s => s.MaSinhVien == ma);
        if (sv != null) sv.LayThongTin();
        else Console.WriteLine("Không tìm thấy sinh viên.");
    }

    public void TimTheoTen(string tuKhoa) 
    {
        var ketQua = danhSach.Where(s => s.HoTen.ToLower().Contains(tuKhoa.ToLower())).ToList(); // Dùng LINQ[cite: 1]
        if (ketQua.Count == 0) Console.WriteLine("Không tìm thấy.");
        foreach (var sv in ketQua) sv.LayThongTin();
    }

    public void SuaDiem(string ma, double diemMoi) 
    {
        var sv = danhSach.FirstOrDefault(s => s.MaSinhVien == ma);
        if (sv != null)
        {
            sv.DiemTrungBinh = diemMoi;
            Console.WriteLine("Cập nhật thành công!");
        }
        else Console.WriteLine("Không tồn tại mã sinh viên này.");
    }

    public void XoaSinhVien(string ma) 
    {
        var sv = danhSach.FirstOrDefault(s => s.MaSinhVien == ma);
        if (sv != null)
        {
            danhSach.Remove(sv);
            Console.WriteLine("Xóa thành công!");
        }
        else Console.WriteLine("Không tìm thấy sinh viên để xóa."); 
    }

    public void SapXepTheoDiemGiamDan() 
    {
        var sortedList = danhSach.OrderByDescending(s => s.DiemTrungBinh).ToList(); 
        foreach (var sv in sortedList) sv.LayThongTin();
    }

    public void LocSinhVienDat() 
    {
        var filteredList = danhSach.Where(s => s.DiemTrungBinh >= 5).ToList(); 
        foreach (var sv in filteredList) sv.LayThongTin();
    }
}