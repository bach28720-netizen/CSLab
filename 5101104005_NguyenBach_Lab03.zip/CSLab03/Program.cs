﻿using System;

class Program
{
    static void Main(string[] args)
    {
        QuanLySinhVien qlsv = new QuanLySinhVien(); 
        bool isRunning = true;

        while (isRunning)
        {
            Console.WriteLine("\n===== QUAN LY SINH VIEN =====");
            Console.WriteLine("1. Them sinh vien");
            Console.WriteLine("2. Xuat danh sach");
            Console.WriteLine("3. Tim sinh vien theo ma");
            Console.WriteLine("4. Tim sinh vien theo ten");
            Console.WriteLine("5. Sua diem trung binh");
            Console.WriteLine("6. Xoa sinh vien");
            Console.WriteLine("7. Sap xep theo diem giam dan");
            Console.WriteLine("8. Loc sinh vien dat");
            Console.WriteLine("0. Thoat"); 
            Console.Write("Chon chuc nang: "); 

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    try
                    {
                        Console.Write("Nhập mã SV: "); string ma = Console.ReadLine();
                        Console.Write("Nhập họ tên: "); string ten = Console.ReadLine();

                        Console.Write("Nhập ngày sinh (yyyy-MM-dd): ");
                        DateTime ngaySinh;
                        while (!DateTime.TryParse(Console.ReadLine(), out ngaySinh))
                        { 
                            Console.Write("Nhập sai định dạng, nhập lại ngày sinh (yyyy-MM-dd): ");
                        }

                        Console.Write("Nhập mã lớp: "); string lop = Console.ReadLine();

                        Console.Write("Nhập điểm TB: ");
                        double diem;
                        while (!double.TryParse(Console.ReadLine(), out diem))
                        { 
                            Console.Write("Điểm phải là số. Nhập lại: ");
                        }

                        SinhVien sv = new SinhVien(ma, ten, ngaySinh, lop, diem);
                        qlsv.ThemSinhVien(sv);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Lỗi: {ex.Message}"); 
                    }
                    break;
                case "2": qlsv.XuatDanhSach(); break;
                case "3":
                    Console.Write("Nhập mã cần tìm: ");
                    qlsv.TimTheoMa(Console.ReadLine());
                    break;
                case "4":
                    Console.Write("Nhập từ khóa tên: ");
                    qlsv.TimTheoTen(Console.ReadLine());
                    break;
                case "5":
                    Console.Write("Nhập mã sinh viên cần sửa: ");
                    string maSua = Console.ReadLine();
                    Console.Write("Nhập điểm mới: ");
                    double diemMoi;
                    if (double.TryParse(Console.ReadLine(), out diemMoi))
                        qlsv.SuaDiem(maSua, diemMoi);
                    else
                        Console.WriteLine("Nhập điểm không hợp lệ."); 
                    break;
                case "6":
                    Console.Write("Nhập mã sinh viên cần xóa: ");
                    qlsv.XoaSinhVien(Console.ReadLine());
                    break;
                case "7": qlsv.SapXepTheoDiemGiamDan(); break;
                case "8": qlsv.LocSinhVienDat(); break;
                case "0": isRunning = false; break;
                default: Console.WriteLine("Chức năng không hợp lệ!"); break;
            }
        }
    }
}