﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductManager
{
    public partial class FrmProduct : Form
    {
        private BindingList<Product> productList;
        private BindingSource bindingSource;
        public FrmProduct()
        {
            InitializeComponent();
            productList = new BindingList<Product>();
            bindingSource = new BindingSource();
        }


        private void FrmProduct_Load(object sender, EventArgs e)
        {
            cboLoaiSP.Items.AddRange(new string[] { "Điện tử", "Văn phòng", "Gia dụng", "Thời trang" });
            cboLoaiSP.SelectedIndex = 0;

            productList.Add(new Product { MaSP = "SP01", TenSP = "Laptop Dell", LoaiSP = "Điện tử", DonGia = 15000000, SoLuong = 10, dtpNgayNhap = DateTime.Now.AddDays(-10), ConKinhDoanh = true });
            productList.Add(new Product { MaSP = "SP02", TenSP = "Bút bi Thiên Long", LoaiSP = "Văn phòng", DonGia = 5000, SoLuong = 100, dtpNgayNhap = DateTime.Now, ConKinhDoanh = true });
            productList.Add(new Product { MaSP = "SP03", TenSP = "Nồi cơm điện", LoaiSP = "Gia dụng", DonGia = 800000, SoLuong = 5, dtpNgayNhap = DateTime.Now.AddDays(-5), ConKinhDoanh = false });

            bindingSource.DataSource = productList;
            dgvProducts.DataSource = bindingSource;

            UpdateStatus("Tải dữ liệu thành công.");
        }

        private bool ValidateInput()
        {
            errorProvider1.Clear();
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(txtMaSP.Text))
            {
                errorProvider1.SetError(txtMaSP, "Mã sản phẩm không được rỗng");
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtTenSP.Text))
            {
                errorProvider1.SetError(txtTenSP, "Tên sản phẩm không được rỗng");
                isValid = false;
            }
            if (numDonGia.Value <= 0)
            {
                errorProvider1.SetError(numDonGia, "Đơn giá phải lớn hơn 0");
                isValid = false;
            }
            if (dtpNgayNhap.Value > DateTime.Now)
            {
                errorProvider1.SetError(dtpNgayNhap, "Ngày nhập không được lớn hơn ngày hiện tại");
                isValid = false;
            }
            return isValid;
        }
        private void ClearInput()
        {
            txtMaSP.Clear();
            txtTenSP.Clear();
            cboLoaiSP.SelectedIndex = 0;
            numDonGia.Value = 0;
            numSoLuong.Value = 0;
            dtpNgayNhap.Value = DateTime.Now;
            chkConKinhDoanh.Checked = false;
            pictureBox1.Image = null;
            txtMaSP.Focus();
            errorProvider1.Clear();
        }
        private void UpdateStatus(string message)
        {
            lblStatus.Text = $"{message} | Tổng số sản phẩm: {productList.Count}";
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            if (productList.Any(p => p.MaSP == txtMaSP.Text.Trim()))
            {
                MessageBox.Show("Mã sản phẩm đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Product newProduct = new Product
            {
                MaSP = txtMaSP.Text.Trim(),
                TenSP = txtTenSP.Text.Trim(),
                LoaiSP = cboLoaiSP.SelectedItem?.ToString() ?? "",
                DonGia = numDonGia.Value,
                SoLuong = (int)numSoLuong.Value,
                dtpNgayNhap = dtpNgayNhap.Value,
                ConKinhDoanh = chkConKinhDoanh.Checked,
                DuongDanAnh = pictureBox1.ImageLocation
            };
            productList.Add(newProduct);
            ClearInput();
            UpdateStatus("Đã thêm sản phẩm mới.");
        }

        private void dgvProducts_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow != null && dgvProducts.CurrentRow.DataBoundItem is Product p)
            {
                txtMaSP.Text = p.MaSP;
                txtTenSP.Text = p.TenSP;
                cboLoaiSP.SelectedItem = p.LoaiSP;
                numDonGia.Value = p.DonGia;
                numSoLuong.Value = p.SoLuong;
                dtpNgayNhap.Value = p.dtpNgayNhap;
                chkConKinhDoanh.Checked = p.ConKinhDoanh;
                pictureBox1.ImageLocation = p.DuongDanAnh;
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow == null) return;

            if (MessageBox.Show("Bạn có chắc chắn muốn xóa sản phẩm này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Product p = (Product)dgvProducts.CurrentRow.DataBoundItem;
                productList.Remove(p);
                ClearInput();
                UpdateStatus("Đã xóa sản phẩm.");
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow == null) return;
            if (!ValidateInput()) return;

            Product p = (Product)dgvProducts.CurrentRow.DataBoundItem;

            if (p.MaSP != txtMaSP.Text.Trim() && productList.Any(x => x.MaSP == txtMaSP.Text.Trim()))
            {
                MessageBox.Show("Mã sản phẩm mới đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            p.MaSP = txtMaSP.Text.Trim();
            p.TenSP = txtTenSP.Text.Trim();
            p.LoaiSP = cboLoaiSP.SelectedItem.ToString();
            p.DonGia = numDonGia.Value;
            p.SoLuong = (int)numSoLuong.Value;
            p.dtpNgayNhap = dtpNgayNhap.Value;
            p.ConKinhDoanh = chkConKinhDoanh.Checked;
            p.DuongDanAnh = pictureBox1.ImageLocation;

            bindingSource.ResetBindings(false);
            UpdateStatus("Đã cập nhật sản phẩm.");
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            ClearInput();
            bindingSource.DataSource = productList;
            UpdateStatus("Đã làm mới dữ liệu.");
        }

        private void btnChonAnh_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.ImageLocation = ofd.FileName;
                    pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                }
            }
        }
    }
}
