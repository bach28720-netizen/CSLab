﻿namespace CourseResgistrationApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            dtpNgaySinh = new DateTimePicker();
            txtSoDienThoai = new TextBox();
            chkNhanEmail = new CheckBox();
            label3 = new Label();
            txtHoTen = new TextBox();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            label5 = new Label();
            numSoThang = new NumericUpDown();
            lblTongTien = new Label();
            radOffline = new RadioButton();
            radOnline = new RadioButton();
            cboKhoaHoc = new ComboBox();
            label4 = new Label();
            btnDangKy = new Button();
            btnLamMoi = new Button();
            btnThoat = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numSoThang).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(dtpNgaySinh);
            groupBox1.Controls.Add(txtSoDienThoai);
            groupBox1.Controls.Add(chkNhanEmail);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtHoTen);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(0, 0);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(556, 258);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "THÔNG TIN CÁ NHÂN";
            // 
            // dtpNgaySinh
            // 
            dtpNgaySinh.Location = new Point(223, 136);
            dtpNgaySinh.Name = "dtpNgaySinh";
            dtpNgaySinh.Size = new Size(300, 31);
            dtpNgaySinh.TabIndex = 6;
            // 
            // txtSoDienThoai
            // 
            txtSoDienThoai.BorderStyle = BorderStyle.FixedSingle;
            txtSoDienThoai.Location = new Point(223, 86);
            txtSoDienThoai.Name = "txtSoDienThoai";
            txtSoDienThoai.Size = new Size(300, 31);
            txtSoDienThoai.TabIndex = 5;
            // 
            // chkNhanEmail
            // 
            chkNhanEmail.AutoSize = true;
            chkNhanEmail.Location = new Point(43, 190);
            chkNhanEmail.Name = "chkNhanEmail";
            chkNhanEmail.Size = new Size(216, 29);
            chkNhanEmail.TabIndex = 4;
            chkNhanEmail.Text = "Nhận email thông báo";
            chkNhanEmail.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(43, 136);
            label3.Name = "label3";
            label3.Size = new Size(91, 25);
            label3.TabIndex = 2;
            label3.Text = "Ngày sinh";
            // 
            // txtHoTen
            // 
            txtHoTen.BorderStyle = BorderStyle.FixedSingle;
            txtHoTen.Location = new Point(223, 37);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(300, 31);
            txtHoTen.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(43, 86);
            label2.Name = "label2";
            label2.Size = new Size(117, 25);
            label2.TabIndex = 1;
            label2.Text = "Số điện thoại";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 37);
            label1.Name = "label1";
            label1.Size = new Size(67, 25);
            label1.TabIndex = 0;
            label1.Text = "Họ Tên";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(numSoThang);
            groupBox2.Controls.Add(lblTongTien);
            groupBox2.Controls.Add(radOffline);
            groupBox2.Controls.Add(radOnline);
            groupBox2.Controls.Add(cboKhoaHoc);
            groupBox2.Controls.Add(label4);
            groupBox2.Location = new Point(0, 298);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(556, 280);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "THÔNG TIN KHÓA HỌC";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(33, 153);
            label5.Name = "label5";
            label5.Size = new Size(153, 25);
            label5.TabIndex = 7;
            label5.Text = "Số tháng đăng ký";
            // 
            // numSoThang
            // 
            numSoThang.Location = new Point(223, 151);
            numSoThang.Name = "numSoThang";
            numSoThang.Size = new Size(180, 31);
            numSoThang.TabIndex = 6;
            numSoThang.ValueChanged += numSoThang_ValueChanged;
            // 
            // lblTongTien
            // 
            lblTongTien.AutoSize = true;
            lblTongTien.Location = new Point(33, 214);
            lblTongTien.Name = "lblTongTien";
            lblTongTien.Size = new Size(87, 25);
            lblTongTien.TabIndex = 2;
            lblTongTien.Text = "Tổng tiền";
            // 
            // radOffline
            // 
            radOffline.AutoSize = true;
            radOffline.Location = new Point(223, 97);
            radOffline.Name = "radOffline";
            radOffline.Size = new Size(169, 29);
            radOffline.TabIndex = 5;
            radOffline.TabStop = true;
            radOffline.Text = "Hình thức offline";
            radOffline.UseVisualStyleBackColor = true;
            // 
            // radOnline
            // 
            radOnline.AutoSize = true;
            radOnline.Location = new Point(33, 97);
            radOnline.Name = "radOnline";
            radOnline.Size = new Size(167, 29);
            radOnline.TabIndex = 4;
            radOnline.TabStop = true;
            radOnline.Text = "Hình thức online";
            radOnline.UseVisualStyleBackColor = true;
            // 
            // cboKhoaHoc
            // 
            cboKhoaHoc.FormattingEnabled = true;
            cboKhoaHoc.Location = new Point(223, 41);
            cboKhoaHoc.Name = "cboKhoaHoc";
            cboKhoaHoc.Size = new Size(182, 33);
            cboKhoaHoc.TabIndex = 3;
            cboKhoaHoc.SelectedIndexChanged += cboKhoaHoc_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(33, 49);
            label4.Name = "label4";
            label4.Size = new Size(86, 25);
            label4.TabIndex = 2;
            label4.Text = "Khóa học";
            // 
            // btnDangKy
            // 
            btnDangKy.Location = new Point(718, 163);
            btnDangKy.Name = "btnDangKy";
            btnDangKy.Size = new Size(112, 34);
            btnDangKy.TabIndex = 2;
            btnDangKy.Text = "Đăng Ký";
            btnDangKy.UseVisualStyleBackColor = true;
            btnDangKy.Click += btnDangKy_Click;
            // 
            // btnLamMoi
            // 
            btnLamMoi.Location = new Point(718, 268);
            btnLamMoi.Name = "btnLamMoi";
            btnLamMoi.Size = new Size(112, 34);
            btnLamMoi.TabIndex = 3;
            btnLamMoi.Text = "Làm Mới";
            btnLamMoi.UseVisualStyleBackColor = true;
            btnLamMoi.Click += btnLamMoi_Click;
            // 
            // btnThoat
            // 
            btnThoat.Location = new Point(718, 364);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(112, 34);
            btnThoat.TabIndex = 4;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1252, 634);
            Controls.Add(btnThoat);
            Controls.Add(btnLamMoi);
            Controls.Add(btnDangKy);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "CSLab05";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numSoThang).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label3;
        private Label label2;
        private Label label1;
        private DateTimePicker dateTimePicker1;
        private TextBox textBox2;
        private TextBox txtHoTen;
        private CheckBox chkNhanEmail;
        private GroupBox groupBox2;
        private RadioButton radOffline;
        private RadioButton radOnline;
        private ComboBox cboKhoaHoc;
        private Label label4;
        private DateTimePicker dateTimePicker2;
        private TextBox txtSoDienThoai;
        private Label label5;
        private NumericUpDown numSoThang;
        private Label lblTongTien;
        private Button btnDangKy;
        private Button btnLamMoi;
        private Button btnThoat;
        private DateTimePicker dtpNgaySinh;
    }
}