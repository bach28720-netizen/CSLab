﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CourseResgistrationApp
{
    public partial class Form1 : Form
    {
        public class KhoaHoc
        {
            public string TenKhoaHoc { get; set; }
            public decimal HocPhi { get; set; }

            public override string ToString()
            {
                return TenKhoaHoc;
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cboKhoaHoc.Items.Add(new KhoaHoc { TenKhoaHoc = "C# WinForms cơ bản", HocPhi = 800000 });
            cboKhoaHoc.Items.Add(new KhoaHoc { TenKhoaHoc = "SQL Server cơ bản", HocPhi = 700000 });
            cboKhoaHoc.Items.Add(new KhoaHoc { TenKhoaHoc = "Web Frontend cơ bản", HocPhi = 750000 });
            cboKhoaHoc.Items.Add(new KhoaHoc { TenKhoaHoc = "Lập trình Python cơ bản", HocPhi = 650000 });

            cboKhoaHoc.SelectedIndex = 0;
            radOnline.Checked = true;
            numSoThang.Minimum = 1;
            numSoThang.Maximum = 12;

            TinhTongHocPhi();
        }
        private void TinhTongHocPhi()
        {
            if (cboKhoaHoc.SelectedItem != null)
            {
                KhoaHoc kh = (KhoaHoc)cboKhoaHoc.SelectedItem;
                decimal tongTien = kh.HocPhi * numSoThang.Value;
                lblTongTien.Text = string.Format("{0:N0} VNĐ", tongTien);
            }
        }

        private void cboKhoaHoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            TinhTongHocPhi();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Vui lòng nhập họ tên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtSoDienThoai.Text))
            {
                MessageBox.Show("Vui lòng nhập số điện thoại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSoDienThoai.Focus();
                return;
            }

            if (cboKhoaHoc.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng chọn khóa học!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string hoTen = txtHoTen.Text;
            string sdt = txtSoDienThoai.Text;
            string ngaySinh = dtpNgaySinh.Value.ToString("dd/MM/yyyy");
            string khoaHoc = ((KhoaHoc)cboKhoaHoc.SelectedItem).TenKhoaHoc;
            string hinhThuc = radOnline.Checked ? "Online" : "Trực tiếp";
            decimal soThang = numSoThang.Value;
            string tongTien = lblTongTien.Text;
            string nhanEmail = chkNhanEmail.Checked ? "Có" : "Không";

            string thongBao = $"--- PHIẾU ĐĂNG KÝ ---\n" +
                              $"Họ tên: {hoTen}\n" +
                              $"Số điện thoại: {sdt}\n" +
                              $"Ngày sinh: {ngaySinh}\n" +
                              $"Khóa học: {khoaHoc}\n" +
                              $"Hình thức: {hinhThuc}\n" +
                              $"Số tháng: {soThang}\n" +
                              $"Tổng tiền: {tongTien}\n" +
                              $"Nhận Email: {nhanEmail}";

            MessageBox.Show(thongBao, "Xác nhận đăng ký", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void numSoThang_ValueChanged(object sender, EventArgs e)
        {
            TinhTongHocPhi();
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            txtHoTen.Clear();
            txtSoDienThoai.Clear();
            dtpNgaySinh.Value = DateTime.Now;
            chkNhanEmail.Checked = false;
            cboKhoaHoc.SelectedIndex = 0;
            radOnline.Checked = true;
            numSoThang.Value = 1;
            txtHoTen.Focus();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
