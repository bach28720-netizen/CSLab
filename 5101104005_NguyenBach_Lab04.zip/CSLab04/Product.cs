﻿using System;

public class Product : IEntity
{
    public string MaSP { get; set; }
    public string TenSP { get; set; }

    private double _price;
    public double Price
    {
        get => _price;
        set => _price = value >= 0 ? value : throw new ArgumentException("Giá không được âm.");
    }

    private int _quantity;
    public int Quantity
    {
        get => _quantity;
        set => _quantity = value >= 0 ? value : throw new ArgumentException("Số lượng không được âm.");
    }

    public string Id => MaSP;

    public Product(string maSP, string tenSP, double price, int quantity)
    {
        if (string.IsNullOrWhiteSpace(maSP))
            throw new ArgumentException("Mã sản phẩm không được rỗng.");

        MaSP = maSP;
        TenSP = tenSP;
        Price = price;
        Quantity = quantity;
    }

    public override string ToString()
    {
        return $"Mã: {MaSP,-5} | Tên: {TenSP,-15} | Giá: {Price,-10} | SL: {Quantity,-5}";
    }
}