﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSLab04.Exceptions
{
    internal class DuplicateProductException
    {
    }
}
