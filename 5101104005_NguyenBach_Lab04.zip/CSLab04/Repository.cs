﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Repository<T> where T : IEntity
{
    private List<T> _items = new List<T>();

    public void Add(T item)
    {
        _items.Add(item);
    }

    public void Remove(T item)
    {
        _items.Remove(item);
    }

    public T FindById(string id)
    {
        return _items.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
    }

    public List<T> Find(Func<T, bool> predicate)
    {
        return _items.Where(predicate).ToList();
    }

    public List<T> GetAll()
    {
        return _items.ToList();
    }
}