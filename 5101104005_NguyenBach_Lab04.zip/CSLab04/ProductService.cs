﻿using System;
using System.Collections.Generic;
using System.Linq;

public class ProductService
{
    private Repository<Product> _repository;

    public event Action<string> OnNotification;

    public ProductService()
    {
        _repository = new Repository<Product>();
    }

    public void AddProduct(Product product)
    {
        if (_repository.FindById(product.MaSP) != null)
        {
            throw new DuplicateProductException($"Mã sản phẩm '{product.MaSP}' đã tồn tại.");
        }

        _repository.Add(product);
        OnNotification?.Invoke($"Đã thêm thành công sản phẩm: {product.TenSP}");
    }

    public void RemoveProduct(string maSP)
    {
        var product = _repository.FindById(maSP);
        if (product == null)
        {
            throw new ProductNotFoundException($"Không tìm thấy sản phẩm có mã '{maSP}' để xóa.");
        }

        _repository.Remove(product);
        OnNotification?.Invoke($"Đã xóa thành công sản phẩm mã: {maSP}");
    }

    public List<Product> GetAll() => _repository.GetAll();

    public Product FindById(string maSP) => _repository.FindById(maSP);

    public List<Product> SearchByName(string keyword)
    {
        return _repository.Find(p => p.TenSP.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0);
    }

    public List<Product> FilterByPrice(Func<Product, bool> criteria)
    {
        return _repository.Find(criteria);
    }

    public double CalculateTotalValue()
    {
        return _repository.GetAll().Sum(p => p.Price * p.Quantity);
    }
}