﻿using System;
using System.Collections.Generic;

class Program
{
    static ProductService _service = new ProductService();


    static void Main(string[] args)
    {
        _service.OnNotification += HandleNotification;
        
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;
            _service.OnNotification += HandleNotification;

            bool isRunning = true;
          
       
        while (isRunning)
        {
            Console.Clear();
            Console.WriteLine("===== PRODUCT MANAGER =====");
            Console.WriteLine("1. Them san pham");
            Console.WriteLine("2. Xuat danh sach");
            Console.WriteLine("3. Tim theo ma");
            Console.WriteLine("4. Tim theo ten");
            Console.WriteLine("5. Loc theo khoang gia");
            Console.WriteLine("6. Xoa san pham");
            Console.WriteLine("7. Tinh tong gia tri kho");
            Console.WriteLine("0. Thoat");
            Console.Write("Chon: ");

            string choice = Console.ReadLine();
            Console.WriteLine();

            try
            {
                switch (choice)
                {
                    case "1": AddProductUI(); break;
                    case "2": ShowAllUI(); break;
                    case "3": FindByIdUI(); break;
                    case "4": SearchByNameUI(); break;
                    case "5": FilterByPriceUI(); break;
                    case "6": RemoveProductUI(); break;
                    case "7": ShowTotalValueUI(); break;
                    case "0": isRunning = false; break;
                    default: Console.WriteLine("Lựa chọn không hợp lệ!"); break;
                }
            }
            catch (DuplicateProductException ex)
            {
                Console.WriteLine($"[LỖI TRÙNG MÃ]: {ex.Message}");
            }
            catch (ProductNotFoundException ex)
            {
                Console.WriteLine($"[LỖI KHÔNG TÌM THẤY]: {ex.Message}");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"[LỖI DỮ LIỆU]: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[LỖI HỆ THỐNG]: Đã xảy ra lỗi không xác định. {ex.Message}");
            }

            if (isRunning)
            {
                Console.WriteLine("\nNhấn phím bất kỳ để tiếp tục...");
                Console.ReadKey();
            }
        }
    }

    static void HandleNotification(string message)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"[THÔNG BÁO] {message}");
        Console.ResetColor();
    }

    static void AddProductUI()
    {
        Console.Write("Nhập mã SP: ");
        string maSP = Console.ReadLine();

        Console.Write("Nhập tên SP: ");
        string tenSP = Console.ReadLine();

        Console.Write("Nhập giá: ");
        if (!double.TryParse(Console.ReadLine(), out double price))
            throw new ArgumentException("Giá phải là số.");

        Console.Write("Nhập số lượng: ");
        if (!int.TryParse(Console.ReadLine(), out int quantity))
            throw new ArgumentException("Số lượng phải là số nguyên.");

        Product p = new Product(maSP, tenSP, price, quantity);
        _service.AddProduct(p);
    }

    static void ShowAllUI()
    {
        var list = _service.GetAll();
        if (list.Count == 0)
        {
            Console.WriteLine("Danh sách rỗng.");
            return;
        }
        foreach (var p in list) Console.WriteLine(p);
    }

    static void FindByIdUI()
    {
        Console.Write("Nhập mã SP cần tìm: ");
        string id = Console.ReadLine();
        var p = _service.FindById(id);
        if (p != null) Console.WriteLine(p);
        else Console.WriteLine("Không tìm thấy sản phẩm.");
    }

    static void SearchByNameUI()
    {
        Console.Write("Nhập từ khóa tên SP: ");
        string keyword = Console.ReadLine();
        var list = _service.SearchByName(keyword);
        PrintList(list);
    }

    static void FilterByPriceUI()
    {
        Console.Write("Nhập giá MIN: ");
        double min = double.Parse(Console.ReadLine());
        Console.Write("Nhập giá MAX: ");
        double max = double.Parse(Console.ReadLine());

        Func<Product, bool> priceCondition = p => p.Price >= min && p.Price <= max;
        var list = _service.FilterByPrice(priceCondition);

        PrintList(list);
    }

    static void RemoveProductUI()
    {
        Console.Write("Nhập mã SP cần xóa: ");
        string id = Console.ReadLine();
        _service.RemoveProduct(id);
    }

    static void ShowTotalValueUI()
    {
        Console.WriteLine($"Tổng giá trị kho: {_service.CalculateTotalValue():N2}");
    }

    static void PrintList(List<Product> list)
    {
        if (list.Count == 0) Console.WriteLine("Không có sản phẩm nào thỏa điều kiện.");
        else foreach (var p in list) Console.WriteLine(p);
    }

}