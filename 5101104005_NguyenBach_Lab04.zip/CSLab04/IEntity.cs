﻿using System;

public interface IEntity
{
    string Id { get; }
}

public class DuplicateProductException : Exception
{
    public DuplicateProductException(string message) : base(message) { }
}

public class ProductNotFoundException : Exception
{
    public ProductNotFoundException(string message) : base(message) { }
}