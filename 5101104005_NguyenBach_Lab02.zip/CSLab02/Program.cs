﻿using System;

namespace Lab02
{
    class Program
    {
        static int NhapSoNguyenDuong(string message)
        {
            int n;
            while (true)
            {
                Console.Write(message);
                if (int.TryParse(Console.ReadLine(), out n) && n > 0)
                {
                    return n;
                }
                Console.WriteLine("Loi: Vui long nhap so nguyen duong (n > 0)!");
            }
        }

        static int[] NhapMang()
        {
            int n = NhapSoNguyenDuong("Nhap so luong phan tu n: ");
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhap phan tu thu {i}: ");
                while (!int.TryParse(Console.ReadLine(), out a[i]))
                {
                    Console.WriteLine("Loi: Vui long nhap mot so nguyen!");
                    Console.Write($"Nhap lai phan tu thu {i}: ");
                }
            }
            return a;
        }
        static void XuatMang(int[] a)
        {
            Console.Write("Cac phan tu trong mang: ");
            foreach (int item in a)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
        }

        static int TinhTong(int[] a)
        {
            int sum = 0;
            foreach (int item in a)
            {
                sum += item;
            }
            return sum;
        }

        
        static void Main(string[] args)
        {
            int[] arr = null;
            int choice = -1;

            do
            {
                Console.WriteLine("\n===== MENU =====");
                Console.WriteLine("1. Nhap mang");
                Console.WriteLine("2. Xuat mang");
                Console.WriteLine("3. Tinh tong");
                Console.WriteLine("4. Tim max/min");
                Console.WriteLine("5. Dem chan/le");
                Console.WriteLine("6. Sap xep tang dan");
                Console.WriteLine("7. Tim kiem");
                Console.WriteLine("0. Thoat");
                Console.Write("Chon chuc nang: ");

                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Vui long nhap so de chon chuc nang!");
                    continue;
                }

                if (choice >= 2 && choice <= 7 && arr == null)
                {
                    Console.WriteLine("Ban chua nhap mang! Vui long chon 1 de nhap mang truoc.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        arr = NhapMang(); 
                        break;
                    case 2:
                        XuatMang(arr); 
                        break;
                    case 3:
                        Console.WriteLine($"Tong cac phan tu trong mang la: {TinhTong(arr)}"); //
                        break;
                    case 4:
                        Console.WriteLine("Chuc nang dang duoc xay dung...");
                        break;
                    case 5:
                        break;
                    case 6:
                        break;
                    case 7:
                        break;
                    case 0:
                        Console.WriteLine("Chuong trinh ket thuc.");
                        break;
                    default:
                        Console.WriteLine("Chuc nang khong hop le. Vui long chon tu 0 den 7.");
                        break;
                }
            } while (choice != 0);
        }
    }
}